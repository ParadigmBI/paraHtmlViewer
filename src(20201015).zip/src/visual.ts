import "./../style/visual.less";

import * as d3 from "d3";
import * as $ from "jquery";
import * as _ from "lodash";
import powerbi from "powerbi-visuals-api";

import DataView = powerbi.DataView;
import DataViewObjects = powerbi.DataViewObjects;
import DataViewValueColumn = powerbi.DataViewValueColumn;
import DataViewCategoricalColumn = powerbi.DataViewCategoricalColumn;
import DataViewCategoryColumn = powerbi.DataViewCategoryColumn;
import PrimitiveValue = powerbi.PrimitiveValue;
import IViewport = powerbi.IViewport;
import VisualObjectInstancesToPersist = powerbi.VisualObjectInstancesToPersist;
import VisualObjectInstance = powerbi.VisualObjectInstance;
import EnumerateVisualObjectInstancesOptions = powerbi.EnumerateVisualObjectInstancesOptions;
import VisualObjectInstanceEnumeration = powerbi.VisualObjectInstanceEnumeration;
import DataViewValueColumnGroup = powerbi.DataViewValueColumnGroup;
import DataViewMetadataColumn = powerbi.DataViewMetadataColumn;
import VisualObjectInstanceEnumerationObject = powerbi.VisualObjectInstanceEnumerationObject;

import ILocalizationManager = powerbi.extensibility.ILocalizationManager;
import IVisualHost = powerbi.extensibility.visual.IVisualHost;
import IVisual = powerbi.extensibility.visual.IVisual;
import ISelectionId = powerbi.visuals.ISelectionId;
import VisualTooltipDataItem = powerbi.extensibility.VisualTooltipDataItem;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import IColorPalette = powerbi.extensibility.IColorPalette;
import ISelectionManager = powerbi.extensibility.ISelectionManager;
import IVisualEventService = powerbi.extensibility.IVisualEventService;

import { axis as AxisHelper, axisInterfaces, dataLabelUtils, dataLabelInterfaces } from "powerbi-visuals-utils-chartutils";
import IAxisProperties = axisInterfaces.IAxisProperties;
import IDataLabelInfo = dataLabelInterfaces.IDataLabelInfo;
import LabelEnabledDataPoint = dataLabelInterfaces.LabelEnabledDataPoint;

import * as formattingutils from "powerbi-visuals-utils-formattingutils";
import { valueFormatter as vf, textMeasurementService as tms} from "powerbi-visuals-utils-formattingutils";
import valueFormatter = formattingutils.valueFormatter;
import IValueFormatter = vf.IValueFormatter;
import textMeasurementService = tms;

import * as SVGUtil from "powerbi-visuals-utils-svgutils";
import ClassAndSelector = SVGUtil.CssConstants.ClassAndSelector;
import createClassAndSelector = SVGUtil.CssConstants.createClassAndSelector;
import IRect = SVGUtil.IRect;
import shapes = SVGUtil.shapes;
import IMargin = SVGUtil.IMargin;

import { valueType as vt, pixelConverter as PixelConverter } from "powerbi-visuals-utils-typeutils";

import { TooltipEventArgs, ITooltipServiceWrapper, createTooltipServiceWrapper } from "powerbi-visuals-utils-tooltiputils";
import { ColorHelper } from "powerbi-visuals-utils-colorutils";

import { interactivityBaseService as interactivityService, interactivitySelectionService } from "powerbi-visuals-utils-interactivityutils";
import appendClearCatcher = interactivityService.appendClearCatcher;
import IInteractiveBehavior = interactivityService.IInteractiveBehavior;
import IInteractivityService = interactivityService.IInteractivityService;
import createInteractivitySelectionService = interactivitySelectionService.createInteractivitySelectionService;
import SelectableDataPoint = interactivitySelectionService.SelectableDataPoint;
import BaseDataPoint = interactivityService.BaseDataPoint;
import IBehaviorOptions = interactivityService.IBehaviorOptions;

import { behavior } from "./behavior";
import { update } from "powerbi-visuals-utils-chartutils/lib/legend/legendData";
type Selection = d3.Selection<any, any, any, any>;


export interface SelectionIdOption extends LabelEnabledDataPoint, SelectableDataPoint {
    identity: ISelectionId;
    index?: number;
    depth?: number;
    values?: string;
    series?: string;
    category?: string;
    selected: boolean;
}

export class SettingState {
    licenseSupport: string = "https://dataviz.boutique";
    templateUrl: string = "https://";
    targetUrl: string = "https://";
    licenseVersion: string = "1.5.0";
    licenseDate: string = "";
    licenseKey: string = "Api 2.6.0";
    padding: number = 20;
    margin: number = 20;
    borderShow: boolean = true;
    categoryShow: boolean = true;
    categoryFontSize: number = 26;
    categoryFontColor: string = "#000000";
    categoryFontFamily: string = "Arial";
    categoryFontWeight: string = "Bold";
    borderColor: string = "#000000";
    borderSize: number = 1;
    htmlType: number = 1;
    widthType: number = 1;
    fixedWidth: boolean = true;
    htmlWidth: number = 300;
    sHtml: boolean = true;
    textAlign: string = "Left";
    textColor: string = "#000000";
    textSize: number = 11;
}

export class Visual implements IVisual {

    private lineChart: Selection;
    private hoverDiv: Selection;
    private bigDiv: Selection;
    private htmlDiv: Selection;
    private settings: SettingState;
    private previousUpdateData;
    private selectionManager: ISelectionManager;
    private host;
    private selectionIdOptions: SelectionIdOption[];
    private Behavior: behavior;
    private interactivityService: IInteractivityService<BaseDataPoint>;
    private tooltipServiceWrapper: ITooltipServiceWrapper;
    private valueName;
    private landing: Selection ;
    private landingText: Selection ;
    private sandBoxWidth;
    private sandBoxHeight;
    public static firstFlag;
    private events: IVisualEventService;
    private dir: number;
    public static mobileFlag;
    private clipSelection: Selection ;
    private divSelection: Selection ;
    private element;
    private minTargetArr;
    private midTargetArr;
    private maxTargetArr;
    private static rate = 79 / 105;
    private tCnt;
    private statusFlag;
    public valueShapeX;
    public static scrollWidth = 20;
    private templateHTML = "";

    private syncSelectionState(
        selection: Selection ,
        selectionIds
    ): void {
        if (!selection || !selectionIds) {
            return;
        }

        if (!selectionIds.length) {
            this.divSelection.style("opacity", 1);
            return;
        }

        const self: this = this;
        selection.each(function(d) {
            const isSelected: boolean = self.isSelectionIdInArray(selectionIds, d.identity);
            let opacity = isSelected ? 1 : 0.5;
            d3.select(this).style("opacity", opacity);
        });
    }

    private isSelectionIdInArray(selectionIds: ISelectionId[], selectionId: ISelectionId): boolean {
        if (!selectionIds || !selectionId) {
            return false;
        }

        return selectionIds.some((currentSelectionId: ISelectionId) => {
            return currentSelectionId.includes(selectionId);
        });
    }

    public static LOGO = '<defs id="defs9032" /> <sodipodi:namedview inkscape:window-maximized="1" inkscape:window-y="-8" inkscape:window-x="-8" inkscape:window-height="1537" inkscape:window-width="2560" showgrid="false" inkscape:document-rotation="0" inkscape:current-layer="layer1" inkscape:document-units="mm" inkscape:cy="502.18152" inkscape:cx="360.43105" inkscape:zoom="0.98994949" inkscape:pageshadow="2" inkscape:pageopacity="0.0" borderopacity="1.0" bordercolor="#666666" pagecolor="#ffffff" id="base" /> <metadata id="metadata9035"> <rdf:RDF> <cc:Work rdf:about=""> <dc:format>image/svg+xml</dc:format> <dc:type rdf:resource="http://purl.org/dc/dcmitype/StillImage" /> <dc:title></dc:title> </cc:Work> </rdf:RDF> </metadata> <g id="layer1" inkscape:groupmode="layer" inkscape:label="Layer 1"> <g transform="matrix(0.19166108,0,0,-0.19166108,-0.222,280.57935)" style="display:inline" id="g9603"> <g transform="translate(186.271,479.2393)" id="g7179"> <path id="path7181" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 3.354,3.251 5.032,7.503 5.032,12.759 0,5.185 -1.678,9.421 -5.032,12.705 -3.354,3.284 -7.256,4.927 -11.707,4.927 -4.723,0 -8.66,-1.625 -11.809,-4.875 -3.149,-3.25 -4.724,-7.502 -4.724,-12.757 0,-5.325 1.575,-9.596 4.724,-12.811 3.149,-3.215 7.086,-4.822 11.809,-4.822 4.451,0 8.353,1.625 11.707,4.874 M 15.814,-12.965 H 5.032 v 5.809 c -4.792,-4.84 -10.954,-7.261 -18.484,-7.261 -6.846,0 -12.768,2.559 -17.766,7.676 -4.997,5.116 -7.496,11.616 -7.496,19.5 0,7.883 2.499,14.383 7.496,19.499 4.998,5.117 10.92,7.675 17.766,7.675 7.599,0 13.76,-2.454 18.484,-7.365 v 29.146 h 10.782 z" /> </g> <g transform="translate(249.3188,479.291)" id="g7183"> <path id="path7185" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 3.354,3.285 5.032,7.521 5.032,12.707 0,5.186 -1.678,9.421 -5.032,12.705 -3.355,3.284 -7.257,4.927 -11.707,4.927 -4.793,0 -8.763,-1.608 -11.912,-4.823 -3.15,-3.215 -4.724,-7.485 -4.724,-12.809 0,-5.325 1.574,-9.596 4.724,-12.811 3.149,-3.214 7.119,-4.822 11.912,-4.822 4.45,0 8.352,1.642 11.707,4.926 M 15.711,-13.017 H 5.032 v 5.913 c -4.656,-4.91 -10.817,-7.365 -18.485,-7.365 -6.914,0 -12.853,2.541 -17.817,7.624 -4.963,5.082 -7.445,11.6 -7.445,19.552 0,7.883 2.499,14.383 7.496,19.499 4.998,5.117 10.92,7.675 17.766,7.675 7.668,0 13.829,-2.454 18.485,-7.364 v 5.913 h 10.679 z" /> </g> <g transform="translate(312.1611,468.7637)" id="g7187"> <path id="path7189" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c -4.381,-2.628 -8.592,-3.941 -12.631,-3.941 -5.682,0 -10.166,1.608 -13.452,4.823 -3.286,3.216 -4.93,7.934 -4.93,14.158 V 40.036 H -42 v 8.921 h 10.987 V 64.93 h 10.68 V 48.957 h 17.458 v -8.921 h -17.458 v -24.27 c 0,-3.113 0.753,-5.48 2.26,-7.105 1.506,-1.625 3.559,-2.437 6.161,-2.437 2.944,0 5.819,0.933 8.626,2.8 z" /> </g> <g transform="translate(351.8989,479.291)" id="g7191"> <path id="path7193" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 3.355,3.285 5.032,7.521 5.032,12.707 0,5.186 -1.677,9.421 -5.032,12.705 -3.355,3.284 -7.257,4.927 -11.707,4.927 -4.792,0 -8.763,-1.608 -11.912,-4.823 -3.15,-3.215 -4.724,-7.485 -4.724,-12.809 0,-5.325 1.574,-9.596 4.724,-12.811 3.149,-3.214 7.12,-4.822 11.912,-4.822 4.45,0 8.352,1.642 11.707,4.926 M 15.711,-13.017 H 5.032 v 5.913 c -4.656,-4.91 -10.817,-7.365 -18.485,-7.365 -6.914,0 -12.853,2.541 -17.817,7.624 -4.963,5.082 -7.445,11.6 -7.445,19.552 0,7.883 2.499,14.383 7.497,19.499 4.997,5.117 10.919,7.675 17.765,7.675 7.668,0 13.829,-2.454 18.485,-7.364 v 5.913 h 10.679 z" /> </g> <g transform="translate(407.4502,466.2744)" id="g7195"> <path id="path7197" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 h -11.398 l -21.874,51.55 h 11.604 l 16.02,-38.689 16.02,38.689 h 11.605 z" /> </g> <path id="path7199" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 436.712,517.721 h 10.68 v -51.446 h -10.68 z m 10.167,20.225 c 1.301,-1.314 1.952,-2.904 1.952,-4.771 0,-1.937 -0.635,-3.527 -1.901,-4.772 -1.266,-1.244 -2.892,-1.867 -4.877,-1.867 -1.986,0 -3.629,0.623 -4.93,1.867 -1.301,1.245 -1.951,2.835 -1.951,4.772 0,1.867 0.65,3.457 1.951,4.771 1.301,1.314 2.944,1.97 4.93,1.97 1.916,0 3.525,-0.656 4.826,-1.97" /> <g transform="translate(502.022,466.2744)" id="g7201"> <path id="path7203" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 h -44.67 v 7.157 l 30.293,35.368 h -29.472 v 8.921 h 42.616 v -7.26 L -31.526,8.92 H 0 Z" /> </g> <g transform="translate(519.3223,477.1133)" id="g7205"> <path id="path7207" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 1.267,-1.279 1.9,-2.818 1.9,-4.615 0,-1.867 -0.633,-3.441 -1.9,-4.72 -1.267,-1.278 -2.858,-1.919 -4.775,-1.919 -1.916,0 -3.526,0.641 -4.827,1.919 -1.3,1.279 -1.951,2.853 -1.951,4.72 0,1.797 0.651,3.336 1.951,4.615 1.301,1.279 2.911,1.919 4.827,1.919 C -2.858,1.919 -1.267,1.279 0,0" /> </g> <g transform="translate(570.3066,479.1875)" id="g7209"> <path id="path7211" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 3.149,3.215 4.724,7.485 4.724,12.811 0,5.324 -1.575,9.593 -4.724,12.808 -3.149,3.216 -7.12,4.823 -11.912,4.823 -4.45,0 -8.352,-1.642 -11.706,-4.926 -3.355,-3.285 -5.032,-7.52 -5.032,-12.705 0,-5.187 1.677,-9.422 5.032,-12.707 3.354,-3.285 7.256,-4.926 11.706,-4.926 4.792,0 8.763,1.607 11.912,4.822 m 7.599,32.31 c 4.998,-5.117 7.497,-11.617 7.497,-19.499 0,-7.953 -2.482,-14.47 -7.445,-19.552 -4.964,-5.083 -10.902,-7.624 -17.818,-7.624 -7.667,0 -13.828,2.455 -18.483,7.364 v -5.912 H -39.331 V 61.766 H -28.65 V 32.62 c 4.655,4.91 10.816,7.364 18.483,7.364 6.847,0 12.769,-2.557 17.766,-7.674" /> </g> <g transform="translate(629.042,479.291)" id="g7213"> <path id="path7215" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 3.354,3.285 5.032,7.521 5.032,12.707 0,5.186 -1.678,9.421 -5.032,12.705 -3.354,3.284 -7.291,4.927 -11.81,4.927 -4.655,0 -8.643,-1.643 -11.963,-4.927 -3.32,-3.284 -4.98,-7.519 -4.98,-12.705 0,-5.186 1.66,-9.422 4.98,-12.707 3.32,-3.284 7.308,-4.926 11.963,-4.926 4.519,0 8.456,1.642 11.81,4.926 m 7.548,32.051 c 5.237,-5.013 7.856,-11.461 7.856,-19.344 0,-7.884 -2.636,-14.348 -7.908,-19.395 -5.271,-5.048 -11.706,-7.574 -19.306,-7.574 -7.667,0 -14.153,2.526 -19.46,7.574 -5.306,5.047 -7.958,11.511 -7.958,19.395 0,7.883 2.652,14.331 7.958,19.344 5.307,5.012 11.793,7.519 19.46,7.519 7.668,0 14.121,-2.507 19.358,-7.519" /> </g> <g transform="translate(700.8193,466.2744)" id="g7217"> <path id="path7219" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 h -10.68 v 6.328 c -4.313,-5.187 -10.166,-7.78 -17.56,-7.78 -6.162,0 -11.108,2.022 -14.839,6.068 -3.731,4.045 -5.596,9.318 -5.596,15.818 v 31.012 h 10.679 V 22.612 c 0,-4.218 1.113,-7.625 3.337,-10.216 2.225,-2.594 5.186,-3.89 8.883,-3.89 4.724,0 8.421,1.625 11.091,4.874 2.67,3.251 4.005,8.021 4.005,14.313 V 51.446 H 0 Z" /> </g> <g transform="translate(747.9502,468.7637)" id="g7221"> <path id="path7223" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c -4.381,-2.628 -8.592,-3.941 -12.63,-3.941 -5.683,0 -10.167,1.608 -13.453,4.823 -3.286,3.216 -4.93,7.934 -4.93,14.158 V 40.036 H -42 v 8.921 h 10.987 V 64.93 h 10.68 V 48.957 h 17.458 v -8.921 h -17.458 v -24.27 c 0,-3.113 0.753,-5.48 2.26,-7.105 1.506,-1.625 3.559,-2.437 6.161,-2.437 2.944,0 5.819,0.933 8.626,2.8 z" /> </g> <path id="path7225" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 754.416,517.721 h 10.68 v -51.446 h -10.68 z m 10.167,20.225 c 1.301,-1.314 1.951,-2.904 1.951,-4.771 0,-1.937 -0.634,-3.527 -1.9,-4.772 -1.266,-1.244 -2.893,-1.867 -4.878,-1.867 -1.985,0 -3.628,0.623 -4.929,1.867 -1.301,1.245 -1.951,2.835 -1.951,4.772 0,1.867 0.65,3.457 1.951,4.771 1.301,1.314 2.944,1.97 4.929,1.97 1.917,0 3.526,-0.656 4.827,-1.97" /> <g transform="translate(813.3589,479.2393)" id="g7227"> <path id="path7229" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 3.355,3.251 5.031,7.503 5.031,12.759 0,5.185 -1.676,9.421 -5.031,12.705 -3.355,3.284 -7.257,4.927 -11.707,4.927 -4.724,0 -8.66,-1.625 -11.809,-4.875 -3.15,-3.25 -4.724,-7.502 -4.724,-12.757 0,-5.325 1.574,-9.596 4.724,-12.811 3.149,-3.215 7.085,-4.822 11.809,-4.822 4.45,0 8.352,1.625 11.707,4.874 M 15.814,-30.598 H 5.031 v 23.442 c -4.792,-4.84 -10.953,-7.261 -18.484,-7.261 -6.846,0 -12.768,2.559 -17.765,7.676 -4.998,5.116 -7.497,11.616 -7.497,19.5 0,7.883 2.499,14.383 7.497,19.499 4.997,5.117 10.919,7.675 17.765,7.675 7.599,0 13.762,-2.454 18.484,-7.365 v 5.913 h 10.783 z" /> </g> <g transform="translate(889.7559,466.2744)" id="g7231"> <path id="path7233" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 h -10.68 v 6.328 c -4.313,-5.187 -10.166,-7.78 -17.56,-7.78 -6.162,0 -11.108,2.022 -14.839,6.068 -3.731,4.045 -5.596,9.318 -5.596,15.818 v 31.012 h 10.679 V 22.612 c 0,-4.218 1.113,-7.625 3.338,-10.216 2.224,-2.594 5.185,-3.89 8.882,-3.89 4.724,0 8.421,1.625 11.091,4.874 2.67,3.251 4.005,8.021 4.005,14.313 V 51.446 H 0 Z" /> </g> <g transform="translate(915.1167,506.3115)" id="g7235"> <path id="path7237" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 C -3.012,-2.213 -4.895,-5.29 -5.648,-9.231 H 24.339 C 23.517,-5.151 21.806,-2.04 19.204,0.104 16.602,2.247 13.488,3.318 9.859,3.318 6.299,3.318 3.013,2.212 0,0 M 35.327,-16.907 H -5.956 c 0.48,-4.633 2.191,-8.332 5.135,-11.099 2.944,-2.765 6.367,-4.148 10.269,-4.148 7.052,0 12.049,2.973 14.993,8.92 l 9.55,-2.075 c -2.054,-5.324 -5.22,-9.351 -9.498,-12.084 -4.28,-2.73 -9.294,-4.096 -15.045,-4.096 -7.12,0 -13.23,2.524 -18.33,7.572 -5.1,5.048 -7.651,11.548 -7.651,19.499 0,8.022 2.551,14.573 7.651,19.655 5.1,5.083 11.347,7.623 18.741,7.623 6.914,0 12.819,-2.436 17.715,-7.312 4.894,-4.875 7.479,-11.115 7.753,-18.721 z" /> </g> <g transform="translate(526.9536,677.4199)" id="g7239"> <path id="path7241" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 9.901,-0.683 19.288,-0.974 27.81,-0.974 5.373,0 10.563,0.101 15.542,0.281 V 104.574 H 0 Z" /> </g> <g transform="translate(462.3574,688.167)" id="g7243"> <path id="path7245" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 C 14.628,-4.092 29.306,-6.875 43.357,-8.669 V 55.29 H 0 Z" /> </g> <g transform="translate(634.9058,710.1875)" id="g7247"> <path id="path7249" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -8.635 l -24.164,-21.542 -0.013,-0.013 h -0.014 c -0.456,-0.058 -0.913,-0.115 -1.382,-0.172 -0.741,-0.085 -1.511,-0.185 -2.308,-0.27 -1.525,-0.185 -3.135,-0.356 -4.816,-0.541 -0.413,-0.044 -0.842,-0.087 -1.268,-0.13 -0.428,-0.042 -0.869,-0.085 -1.311,-0.128 z" /> </g> <g transform="translate(600.7412,826.4609)" id="g7251"> <path id="path7253" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 -9.204,-8.207 V 0 Z" /> </g> <g transform="translate(620.1172,826.4609)" id="g7255"> <path id="path7257" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 -28.58,-25.475 v 8.635 L -9.688,0 Z" /> </g> <g transform="translate(634.9058,826.4609)" id="g7259"> <path id="path7261" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -4.088 l -43.368,-38.626 v 8.62 L -5.101,0 Z" /> </g> <g transform="translate(591.5376,775.1123)" id="g7263"> <path id="path7265" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 43.368,38.626 V 29.992 L 0,-8.633 Z" /> </g> <g transform="translate(591.5376,757.8457)" id="g7267"> <path id="path7269" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 43.368,38.624 V 30.005 L 0,-8.621 Z" /> </g> <g transform="translate(591.5376,740.5918)" id="g7271"> <path id="path7273" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 43.368,38.625 V 29.99 L 0,-8.635 Z" /> </g> <g transform="translate(591.5376,723.3369)" id="g7275"> <path id="path7277" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 43.368,38.626 V 29.991 L 0,-8.633 Z" /> </g> <g transform="translate(591.5376,706.0693)" id="g7279"> <path id="path7281" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 43.368,38.625 V 30.006 L 0,-8.634 Z" /> </g> <g transform="translate(591.5376,688.8164)" id="g7283"> <path id="path7285" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 43.368,38.624 V 29.99 L 0,-8.635 Z" /> </g> <g transform="translate(622.2686,681.6631)" id="g7287"> <path id="path7289" style="fill:#ffc107;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 12.637,11.257 V 3.505 C 9.902,2.522 7.294,1.725 4.916,1.099 3.477,0.713 2.123,0.399 0.855,0.144 0.584,0.087 0.299,0.058 0,0" /> </g> <g transform="translate(715.9897,863.9639)" id="g7291"> <path id="path7293" style="fill:#ff0000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 0,-2.029 -1.646,-3.67 -3.677,-3.67 h -30.73 c -2.026,0 -3.675,1.641 -3.675,3.67 v 30.736 c 0,2.023 1.649,3.67 3.675,3.67 h 30.73 C -1.646,34.406 0,32.759 0,30.736 Z" /> </g> <g transform="translate(696.0615,914.7852)" id="g7295"> <path id="path7297" style="fill:#7aca11;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c 0,-0.879 -0.689,-1.584 -1.545,-1.584 h -12.913 c -0.854,0 -1.546,0.705 -1.546,1.584 v 13.256 c 0,0.878 0.692,1.577 1.546,1.577 H -1.545 C -0.689,14.833 0,14.134 0,13.256 Z" /> </g> <g transform="translate(681.5859,842.6865)" id="g7299"> <path id="path7301" style="fill:#ffd300;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -175.355 c 5.317,2.332 11.689,5.416 17.829,9.114 V 0 Z" /> </g> <g transform="translate(423.7075,891.1289)" id="g7303"> <path id="path7305" style="fill:#ffd300;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c -14.286,0 -25.867,-11.587 -25.867,-25.873 v -112.996 -71.138 c 0,0 1.122,-16.834 21.96,-23.153 0.582,-0.186 1.128,-0.362 1.731,-0.544 0.674,-0.196 1.258,-0.382 1.752,-0.546 24.567,-7.406 65.386,-17.132 110.417,-17.132 32.73,0 62.833,5.149 89.668,15.176 7.737,4.964 -1.574,5.375 -1.574,5.375 -11.056,-1.769 -36.112,-5.136 -67.031,-5.136 -35.699,0 -86.115,4.631 -130.136,25.731 -8.499,3.865 -8.961,11.141 -8.961,11.141 v 35.76 134.066 c 1.022,5.28 4.857,11.629 17.29,12.329 h 4.966 c 4.85,-0.267 7.584,-0.226 8.847,0 h 114.124 97.443 V 0 H 112.998 Z" /> </g> <g transform="translate(731.9912,668.0156)" id="g7307"> <path id="path7309" style="fill:#ffd300;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 c -1.697,1.699 -8.445,-2.096 -8.445,-2.096 l 0.009,0.023 c -48.412,-30.66 -104.158,-46.21 -166.277,-46.21 -69.986,0 -128.103,20.266 -148.47,28.333 l -0.032,0.01 c -11.444,4.283 -10.934,-2.797 -10.934,-2.797 v -17.031 c 0.062,-1.302 0.998,-6.379 9.778,-9.316 44.216,-13.114 87.327,-19.84 128.235,-19.84 87.482,0 149.331,30.417 185.18,55.153 5.328,3.648 9.139,7.966 9.227,8.068 C -0.109,-3.426 1.028,-1.028 0,0" /> </g> <path id="path7311" style="fill:#ff0000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 505.714,743.457 h -27.128 v 18.564 h 27.128 z" /> <path id="path7313" style="fill:#7aca11;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 570.305,781.994 h -27.128 v 18.563 h 27.128 z" /> <path id="path7315" style="fill:#7aca11;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 634.892,826.461 h -27.127 v 18.564 h 27.127 z" /> <g transform="translate(634.9058,826.4609)" id="g7317"> <path id="path7319" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -4.088 l -43.368,-38.626 -0.057,-0.057 v 8.62 l 0.057,0.057 L -5.101,0 Z" /> </g> <g transform="translate(620.1172,826.4609)" id="g7321"> <path id="path7323" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 -28.58,-25.475 -0.071,-0.057 v 8.635 L -28.58,-16.84 -9.688,0 Z" /> </g> <g transform="translate(634.9058,813.7383)" id="g7325"> <path id="path7327" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -8.634 l -43.368,-38.625 -0.057,-0.057 v 8.633 l 0.057,0.057 z" /> </g> <g transform="translate(634.9058,779.2168)" id="g7329"> <path id="path7331" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -8.635 l -43.368,-38.625 -0.057,-0.055 v 8.632 l 0.057,0.058 z" /> </g> <g transform="translate(634.9058,796.4697)" id="g7333"> <path id="path7335" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -8.619 l -43.368,-38.626 -0.057,-0.057 v 8.621 l 0.057,0.057 z" /> </g> <g transform="translate(634.9058,761.9629)" id="g7337"> <path id="path7339" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -8.635 l -43.368,-38.624 -0.057,-0.057 v 8.633 l 0.057,0.057 z" /> </g> <g transform="translate(634.9058,727.4404)" id="g7341"> <path id="path7343" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -8.634 l -43.368,-38.625 -0.057,-0.056 v 8.634 l 0.057,0.057 z" /> </g> <g transform="translate(634.9058,744.6943)" id="g7345"> <path id="path7347" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -8.619 l -43.368,-38.64 -0.057,-0.056 v 8.632 l 0.057,0.058 z" /> </g> <g transform="translate(634.9058,710.1875)" id="g7349"> <path id="path7351" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -8.635 l -24.164,-21.542 -0.013,-0.013 h -0.014 c -0.456,-0.058 -0.913,-0.115 -1.382,-0.172 -0.741,-0.085 -1.511,-0.185 -2.308,-0.27 -1.525,-0.185 -3.135,-0.356 -4.816,-0.541 -0.413,-0.044 -0.842,-0.087 -1.268,-0.13 -0.428,-0.042 -0.869,-0.085 -1.311,-0.128 z" /> </g> <g transform="translate(634.9058,692.9199)" id="g7353"> <path id="path7355" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="m 0,0 v -7.766 c -2.735,-0.982 -5.343,-1.781 -7.722,-2.392 -1.439,-0.386 -2.792,-0.699 -4.06,-0.955 -0.271,-0.057 -0.556,-0.086 -0.855,-0.144 z" /> </g> <g transform="translate(600.7412,826.4609)" id="g7357"> <path id="path7359" style="fill:#000000;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 0,0 -9.204,-8.207 -9.275,-8.264 V 0 Z" /> </g> </g> </g>';

    private createLandingPage(options) {
        let html = new DOMParser().parseFromString('<svg class="landing" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" sodipodi:docname="Dataviz_Portrait.svg" inkscape:version="1.0 (4035a4fb49, 2020-05-01)" id="svg9038" version="1.1" viewBox="0 0 210 297" height="297" width="210">' + Visual.LOGO + '</svg>', 'application/xml').documentElement;
        d3.select(options.element).node().append(html);
        this.landing = d3.select(".landing");
        this.landingText = d3.select(options.element).append("svg").attr("class", "landingText").attr("height", 220).attr("width", 300);
        this.landingText.selectAll("*").remove();
        $('#sandbox-host').css("overflow", "auto");
        let ll = this.landingText.append("text")
                    .attr("font-size", 15)
                    .attr("x", 0)
                    .attr("y", 30);
        ll.append("tspan")
            .attr("x", 0)
            .attr("dy", "0em")
            .text('Using only 1 field in field «HTML» is free.');
        ll.append("tspan")
            .attr("x", 0)
            .attr("dy", "1.2em")
            .text('Adding more will add a watermark.');
        ll.append("tspan")
            .attr("x", 0)
            .attr("dy", "1.2em")
            .text('Also adding a Category or ');
        ll.append("tspan")
            .attr("x", 0)
            .attr("dy", "1.2em")
            .text('changing any setting will add a watermark.');
        ll.append("tspan")
            .attr("x", 0)
            .attr("dy", "1.2em")
            .text('Request your trial license from ');
        ll.append("tspan")
            .attr("x", 0)
            .attr("dy", "1.2em")
            .text('mailto:license@dataviz.boutique ');
        // ll.append("tspan")
        //     .attr("x", 0)
        //     .attr("dy", "1.2em")
        //     .text('http://dataviz.boutique');
    }

    constructor(options: VisualConstructorOptions) {
        this.events = options.host.eventService;
        let element = options.element;
        this.element = element;
        let sandBoxWidth = $('#sandbox-host').width(), sandBoxHeight = $('#sandbox-host').height();
        this.sandBoxWidth = sandBoxWidth;
        this.sandBoxHeight = sandBoxHeight;
        let landingTextWidth = Math.min(450, sandBoxWidth);
        Visual.firstFlag = true, Visual.mobileFlag = false;
        this.createLandingPage(options);
        $(element).append("<div class='freeDiv'></div>");
        this.bigDiv = d3.select(options.element).append("div").classed("bigDiv", true);
        this.bigDiv.append('div').attr("class", "d3-tip");
        let modal = this.bigDiv.append("div").attr("id", "confirm").classed("modal", true);
        let modalContent = modal.append("div").classed("modal-content", true);
        modalContent.append("spacn").classed("yes", true).classed("close", true).text("×");
        modalContent.append("p").classed("message", true).classed("modal-content", true).text("Some text in the Modal..");
        let that = this;
        // this.bigDiv.append("input").attr("type", "button").attr("value", "Click Me").on("click", function(){that.functionAlert(1);});
        this.htmlDiv = this.bigDiv.append("div").attr("class", "htmlDiv");
        // this.lineChart = this.htmlDiv.append("svg");
        this.selectionManager = options.host.createSelectionManager();
        this.host = options.host;
        this.Behavior = new behavior();
        this.interactivityService = createInteractivitySelectionService(this.host);
        this.selectionManager.registerOnSelectCallback(() => {
            this.syncSelectionState(that.divSelection, this.selectionManager.getSelectionIds());
        });
        this.tooltipServiceWrapper = createTooltipServiceWrapper(
            this.host.tooltipService,
            options.element);
    }

    public static _keyStr = "UVWXYZ01234tuvwxyzABCDEFGHIQRST56789+/=abcdefgJKLMhijklmnopqrsNOP";

    public static DECODE(e) {
        let _keyStr = this._keyStr;
        let t = "";
        let n, r, i;
        let s, o, u, a;
        let f = 0;
        e = e.replace(/[^A-Za-z0-9+/=]/g, "");
        while (f < e.length) {
            s = _keyStr.indexOf(e.charAt(f++));
            o = _keyStr.indexOf(e.charAt(f++));
            u = _keyStr.indexOf(e.charAt(f++));
            a = _keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a;
            t = t + String.fromCharCode(n);
            if (u !== 64) {
                t = t + String.fromCharCode(r);
            }
            if (a !== 64) {
                t = t + String.fromCharCode(i);
            }
        }
        t = this._UTF8_DECODE(t);
        return t;
    }

    public static _UTF8_DECODE(e) {
        let t = "";
        let n = 0;
        let r = 0;
        let c1 = 0;
        let c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++;
            } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2;
            } else {
                c2 = e.charCodeAt(n + 1);
                let c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3;
            }
        }
        return t;
    }

    public static ISVALIDEDATE(license, licenseDate = "") {
        let decodedString = this.DECODE(license).toString();
        let arr = decodedString.split(".");
        if (arr.length !== 3) return false;
        if (arr[0].length !== 2 || arr[1].length !== 2 || arr[2].length !== 4) return false;
        for (let i = 0; i < arr.length; i++)
            if (parseInt(arr[i]) === NaN) return false;
        return arr;
    }

    public static ISVALIDTRIAL(license, licenseKey) {
        let licenseArr = license.split(":");
        if (licenseArr.length !== 2) return false;
        let licenseDate = licenseArr[0];
        let licenseStr = licenseArr[1];
        let dtF = this.ISVALIDEDATE(licenseDate);
        if (dtF) {
            return dtF;
        }
        return false;
    }

    public static GETINFO(license) {
        let licenseArr = license.split(":");
        return this.DECODE(licenseArr[0]) + " " + this.DECODE(licenseArr[1]);
    }

    private numberWithCommas(x: string, split: string, floatDot: string): string {
        x = x.replace(".", floatDot);
        let pattern = /(-?\d+)(\d{3})/;
        if (split === ",") {
            while (pattern.test(x))
                x = x.replace(pattern, "$1,$2");
        } else if (split === "'") {
            while (pattern.test(x))
                x = x.replace(pattern, "$1'$2");
        } else if (split === " ") {
            while (pattern.test(x))
                x = x.replace(pattern, "$1  $2");
        } else {
            while (pattern.test(x))
                x = x.replace(pattern, "$1.$2");
        }
        return x;
    }

    private setSettings(objects) {
        this.setSetting(objects, this.settings, 1, "renderGroup", "templateUrl", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "targetUrl", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "padding", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "margin", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "borderShow", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "htmlType", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "widthType", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "fixedWidth", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "htmlWidth", 0);
        this.setSetting(objects, this.settings, 2, "renderGroup", "borderColor", 0);
        this.setSetting(objects, this.settings, 1, "renderGroup", "borderSize", 0);
        this.setSetting(objects, this.settings, 1, "htmlSetting", "sHtml", 0);
        this.setSetting(objects, this.settings, 1, "htmlSetting", "textAlign", 0);
        this.setSetting(objects, this.settings, 2, "htmlSetting", "textColor", 0);
        this.setSetting(objects, this.settings, 1, "htmlSetting", "textSize", 0);
        this.setSetting(objects, this.settings, 1, "categorySettings", "categoryShow", 0);
        this.setSetting(objects, this.settings, 1, "categorySettings", "categoryFontFamily", 0);
        this.setSetting(objects, this.settings, 1, "categorySettings", "categoryFontWeight", 0);
        this.setSetting(objects, this.settings, 1, "categorySettings", "categoryFontSize", 0);
        this.setSetting(objects, this.settings, 2, "categorySettings", "categoryFontColor", 0);
    }

    private getContextMenu(svg, selection) {
        svg.on('contextmenu', () => {
            const mouseEvent: MouseEvent = (<MouseEvent>d3.event);
            let dataPoint = d3.select(d3.event["currentTarget"]).datum();
            selection.showContextMenu(dataPoint? dataPoint["identity"] : {}, {
                x: mouseEvent.clientX,
                y: mouseEvent.clientY
            });
            mouseEvent.preventDefault();
        }); 
    }

    public static ISDATE(str) {
        let a = str.toString().split("T");
        let dt = a[0].split("-");
        if (dt.length !== 3 || isNaN(dt[0]) || isNaN(dt[1]) || isNaN(dt[2])) return false;
        let time = a[1].split(":");
        if (time.length !== 3 || isNaN(time[0]) || isNaN(time[1])) return false;
        let l = time[2].split(".");
        if (l.length < 2 || isNaN(l[0])) return false;
        let last = l[1];
        if (last[last.length - 1] !== 'Z') return false;
        return true;
    }

    public static GETSTRING(val) {
        let str;
        let dt = new Date(val);
        if (val && dt.toString() !== "Invalid Date" && dt.getFullYear() > 1800 && (Visual.ISDATE(val))) {
            str = dt;
        } else {
            str = val;
        }
        return str;
    }

    private setSelectedIdOptions(categorical, values, dataView) {
        let identity: ISelectionId = null, dataValues = categorical.values;
        this.selectionIdOptions = [];
        let formatter: IValueFormatter, formatterCategory: IValueFormatter, columnsf = dataView.metadata.columns, seriesFlag = false;
        for (let i = 0; i < columnsf.length; i++) {
            if (columnsf[i].roles["category"]) {
                formatterCategory = valueFormatter.create({
                    format: valueFormatter.getFormatStringByColumn(
                        columnsf[i],
                        true),
                });
            }
        }
        if (categorical.categories) {
            let j = 0;
            for(let dataValue of dataValues) {
                let values = dataValue.values;
                for(let i = 0, len = dataValue.values.length; i < len; i++) {
                    let selectionId = this.host.createSelectionIdBuilder().withCategory(categorical.categories[0], i).withMeasure(dataValue.source.queryName).withSeries(categorical.values, dataValue).createSelectionId();
                    this.selectionIdOptions.push({
                        category: formatterCategory.format(Visual.GETSTRING(categorical.categories[0].values[i])),
                        identity: selectionId,
                        values: dataValue.source.displayName,
                        selected: false
                    });
                }
                j++;
            }
            // let cat = categorical.categories[0];
            // for (let i = 0; i < cat.values.length; i++) {
            //     identity = this.host.createSelectionIdBuilder().withCategory(cat, i).createSelectionId();
            //     this.selectionIdOptions.push({
            //         identity: identity,
            //         selected: false
            //     });
            // }
        } else {
            for (let i = 0; i < values.length; i++) {
                identity = this.host.createSelectionIdBuilder().withMeasure(values[i].source.queryName).createSelectionId();
                this.selectionIdOptions.push({
                    identity: identity,
                    category: values[i].source.displayName,
                    selected: false
                });
            }
        }
    }

    private setBehavior(clipSelection) {
        let clearCatcher = d3.select('#sandbox-host');
        let that = this;
        clipSelection.on('click', (d) => {
            // Allow selection only if the visual is rendered in a view that supports interactivity (e.g. Report)
            if (that.host.allowInteractions) {
                const isCrtlPressed: boolean = (<MouseEvent>d3.event).ctrlKey;
                that.selectionManager
                    .select(d.identity, isCrtlPressed)
                    .then((ids: ISelectionId[]) => {
                        that.syncSelectionState(clipSelection, ids);
                    });

                ( < Event > d3.event).stopPropagation();
            }
        });

        clearCatcher.on('click', (d) => {
            if (that.host.allowInteractions) {
                that.selectionManager
                    .clear()
                    .then(() => {
                        that.syncSelectionState(clipSelection, []);
                    });
            }
        });
    }
    
    private getSelectionData(selectionIdOptions, clipSelection) {
        let labelData = [];
        clipSelection.each(function() {
            let sel = d3.select(this);
            let k = 0;
            while (sel.attr("class") === null || sel.attr("class").search('childDiv') < 0) {
                sel = d3.select(sel.node().parentNode);
                k++;
                if (k > 5) break;
            }
            let category = sel.attr("category"), value = sel.attr("value"), i;
            for (i = 0; i < selectionIdOptions.length; i++) {
                if (selectionIdOptions[i].category === category && value && selectionIdOptions[i].values === value) break;
                else if (selectionIdOptions[i].category === category) break;
            }
            if (i < selectionIdOptions.length) labelData.push(selectionIdOptions[i]);
            else labelData.push({identity: null, category: "Total", index: -1, selected: false, depth: 0});
        });
        return labelData;
    }

    private setIdenityIntoDiv() {
        let selectionIdOptions = this.selectionIdOptions;
        this.clipSelection = d3.selectAll(".childDiv").selectAll("*");
        this.divSelection = d3.selectAll(".childDiv");
        this.clipSelection.data(this.getSelectionData(selectionIdOptions, this.clipSelection));
        this.divSelection.data(this.getSelectionData(selectionIdOptions, this.divSelection));
    }

    public update(options: VisualUpdateOptions) {
        this.events.renderingStarted(options);
        // this.createLandingPage(options);
        // assert dataView
        if (!options.dataViews || !options.dataViews[0]) { return; }
        let dataViews = options.dataViews, categorical = dataViews[0].categorical, values = categorical.values;
        let objects = dataViews[0].metadata.objects, that = this;
        this.settings = new SettingState();
        this.setSettings(objects);
        $('#sandbox-host').css("overflow", "hidden");
        this.landing.remove(),this.landingText.remove();
        this.setSetting(objects, this.settings, 1, "licenseGroup", "licenseDate", 0);
        let columns = dataViews[0].metadata.columns, sandboxWidth = $('#sandbox-host').width(), sandboxHeight = $('#sandbox-host').height();
        if (Visual.firstFlag) Visual.firstFlag = false; if (this.sandBoxWidth > 1600) Visual.mobileFlag = true;
        if (Visual.mobileFlag) sandboxWidth = this.sandBoxWidth, sandboxHeight = this.sandBoxHeight;
        let valueArr = [], categories = [];
        this.setSelectedIdOptions(categorical, values, dataViews[0]);
        let innerValueCount = 0;
        this.valueName = [], this.statusFlag = false;
        for (let i = 0; i < values.length; i++) {
            if (values[i].source.roles["value"]) {
                this.valueName.push(values[i].source.displayName);
                let tmp = [];
                for (let j = 0; j < values[i].values.length; j++) { 
                    tmp.push(values[i].values[j]);
                }
                if (categorical.categories) valueArr.push(tmp);
                else valueArr.push(tmp[0]);
            }
        }
        if (categorical.categories) categories = categorical.categories[0].values;
        else categories = this.valueName, valueArr = [valueArr];
        that.templateHTML = "";;
        // using XMLHttpRequest
        let xhr = new XMLHttpRequest();
        xhr.open("GET", this.settings.templateUrl, true);
        xhr.onload = function () {
            that.templateHTML = xhr.responseText;
            that.drawHtml(sandboxWidth, sandboxHeight, valueArr, categories);
        };
        xhr.onerror = function () {
            that.htmlDiv.selectAll("*").remove();
            that.htmlDiv.append("text").text("Document not loaded, check Url");
        }
        xhr.send();
        this.setIdenityIntoDiv();
        this.setBehavior(this.divSelection);
        this.getContextMenu(this.clipSelection, this.selectionManager);
        this.getContextMenu(this.divSelection, this.selectionManager), this.getContextMenu(d3.selectAll(".backG"), this.selectionManager);
        this.tooltipServiceWrapper.addTooltip(this.clipSelection, (tooltipEvent: TooltipEventArgs < SelectionIdOption > ) => this.getTooltipData(tooltipEvent)
            , (tooltipEvent: TooltipEventArgs < SelectionIdOption > ) => tooltipEvent.data.identity);
        this.tooltipServiceWrapper.addTooltip(this.divSelection, (tooltipEvent: TooltipEventArgs < SelectionIdOption > ) => this.getTooltipData(tooltipEvent)
            , (tooltipEvent: TooltipEventArgs < SelectionIdOption > ) => tooltipEvent.data.identity);
        this.events.renderingFinished(options);
    }

    private drawHtml(sandboxWidth, sandboxHeight, valueArr, categories) {
        this.htmlDiv.selectAll("*").remove();
        let maxWidth;
        this.bigDiv.style('overflow', 'auto');
        this.htmlDiv.append("div").classed("backG", true).style("opacity", 0);
        this.bigDiv.style('width', sandboxWidth + "px").style('height', sandboxHeight + "px");
        this.htmlDiv.style('width', "9999999px");
        if (this.settings.htmlType === 1) maxWidth = this.drawHtmlColumn(valueArr, categories, sandboxWidth);
        else if (this.settings.htmlType === 2) this.drawHtmlAppend(valueArr, categories, sandboxWidth);
        let htmlWidth = sandboxWidth;
        this.bigDiv.style('overflow', 'hidden auto');
        if (this.settings.widthType === 2) {
            htmlWidth = this.settings.htmlWidth + this.settings.margin * 2 + this.settings.padding * 2;
            if (this.settings.htmlType === 1) htmlWidth *= valueArr.length;
            htmlWidth += Visual.scrollWidth;
        } else if (this.settings.fixedWidth) htmlWidth = Math.max(htmlWidth, maxWidth);
        if(sandboxWidth < htmlWidth) this.bigDiv.style('overflow', 'auto');
        $(".bigDiv").scrollLeft(0).scrollTop(0);
        this.htmlDiv.style('width', htmlWidth + "px").style("position", "absolute");
        // d3.select(".backG").style('width', htmlWidth + "px").style("height", $(".htmlDiv").height() + "px").style("position", "absolute");
    }

    private drawHtmlAppend(valueArr, categories, sandboxWidth) {
        let childWidth = sandboxWidth - (this.settings.margin + this.settings.padding) * 2 - Visual.scrollWidth;
        if (this.settings.widthType === 2) childWidth = this.settings.htmlWidth;
        for (let j = 0; j < valueArr.length; j++) {
            for (let i = 0; i < valueArr[j].length; i++) {
                if (categories.length > 0 && this.settings.categoryShow) {
                    this.htmlDiv.append("h1").text(categories[i]).style("font-size", this.settings.categoryFontSize + "px").style("color", this.settings.categoryFontColor).style("font-family", this.settings.categoryFontFamily).style("font-weight", this.settings.categoryFontWeight);
                }
                let div = this.htmlDiv.append("div").classed("childDiv", true).classed("div_" + j + "_" + i, true).style("padding", this.settings.padding + "px").style("margin", this.settings.margin + "px").style("width", childWidth + "px").attr("category", categories[i]).attr("value", this.selectionIdOptions[j * valueArr[0].length].values);
                if (!this.settings.sHtml) div.style("text-align", this.settings.textAlign).style("color", this.settings.textColor).style("font-size", this.settings.textSize + "px");
                if (this.settings.borderShow) {
                    div.style("border", this.settings.borderSize + "px solid" + this.settings.borderColor);
                }
                let dom = new DOMParser().parseFromString(this.templateHTML, 'text/html');
                let documentElement = dom.documentElement, body = dom.getElementsByTagName("body")[0], html;
                if (body) html = body;
                else html = documentElement;
                let img = html.getElementsByTagName("img");
                // for (let k = img.length - 1; k >= 0; k--) img[k].remove();
                this.replaceAlert(this.nativeSelector(html));
                this.replaceAlert(html.attributes);
                // let childNodes = html.childNodes;
                // for (let k = 0; k < childNodes.length; k++){
                //     div.node().append(childNodes[k]);
                // }
                div.node().append(html);
            }
        }
    }

    private functionAlert(msg) {
        let confirmBox = $("#confirm");
        confirmBox.find(".message").text(msg);
        confirmBox.focus();
        confirmBox.find(".yes").unbind().click(() => {
           confirmBox.hide();
        });
        // confirmBox.find(".yes").click();
        confirmBox.show();
     }

     private nativeSelector(body) {
        var elements = body.querySelectorAll("*");
        var results = [];
        var child;
        for(var i = 0; i < elements.length; i++) {
            child = elements[i].childNodes[0];
            if(elements[i].hasChildNodes() && child.nodeType == 3) {
                results.push(child);
            }
        }
        return results;
    }

    private replaceAlert(textnodes) {
        for (let k = 0, len = textnodes.length; k < len; k++){
            textnodes[k].nodeValue = textnodes[k].nodeValue.replace('javascript:alert','functionAlert');
            textnodes[k].nodeValue = textnodes[k].nodeValue.replace('alert','functionAlert');
        }
    }

    private drawHtmlColumn(valueArr, categories, sandboxWidth) {
        let childWidth = this.settings.htmlWidth, maxWidth = 0;
        if (this.settings.widthType === 1) childWidth = Math.max(0, (sandboxWidth - Visual.scrollWidth) / valueArr.length - this.settings.margin * 2 - this.settings.padding * 2);
        for (let i = 0; i < valueArr[0].length; i++) {
            let parentDiv = this.htmlDiv.append("div").classed("div" + i, true).classed("parentDiv", true), totalWidth = 0;
            if (categories.length > 0 && this.settings.categoryShow) {
                parentDiv.append("h1").text(categories[i]).style("font-size", this.settings.categoryFontSize + "px").style("color", this.settings.categoryFontColor).style("font-family", this.settings.categoryFontFamily).style("font-weight", this.settings.categoryFontWeight);
            }
            for (let j = 0; j < valueArr.length; j++) {
                let div = parentDiv.append("div").classed("div_" + j + "_" + i, true).classed("childDiv", true).style("padding", this.settings.padding + "px").style("margin", this.settings.margin + "px").attr("category", categories[i]).attr("value", this.selectionIdOptions[j * valueArr[0].length].values);
                if (!this.settings.sHtml) div.style("text-align", this.settings.textAlign).style("color", this.settings.textColor).style("font-size", this.settings.textSize + "px");
                if (this.settings.widthType === 2 || !this.settings.fixedWidth)  div.style("width", childWidth + "px");
                if (this.settings.borderShow) {
                    div.style("border", this.settings.borderSize + "px solid" + this.settings.borderColor);
                }
                let dom = new DOMParser().parseFromString(this.templateHTML, 'text/html');
                let documentElement = dom.documentElement, body = dom.getElementsByTagName("body")[0], html;
                if (body) html = body;
                else html = documentElement;
                let img = html.getElementsByTagName("img");
                // for (let k = img.length - 1; k >= 0; k--) img[k].remove();
                this.replaceAlert(this.nativeSelector(html));
                this.replaceAlert(html.attributes);
                div.node().append(html);
                
                // let childNodes = html.childNodes;
                // for (let k = 0; k < childNodes.length; k++){
                //     div.node().append(childNodes[k]);
                // }
                totalWidth += div.node().getBoundingClientRect().width + (this.settings.margin + this.settings.borderSize) * 2;
            }
            maxWidth = Math.max(maxWidth, totalWidth);
            this.htmlDiv.append("div").style("clear", "both");
        }
        return maxWidth;
    }

    private getTooltipData(value: any): VisualTooltipDataItem[] {
        let sel = d3.select(value.context);
        while (sel.attr("class") === null || sel.attr("class").search('childDiv') < 0) {
            sel = d3.select(sel.node().parentNode);
        }
        let category = sel.attr("category");
        let valueName = sel.attr("value");
        let result = [];
        if (category) result.push({displayName: "Category", value: category});
        if (valueName) result.push({displayName: "Value", value: valueName});
        return result;
    }

    private setSetting(objects: DataViewObjects, settings: SettingState,
        mode: number, objectName: string, propertyName: string, index: number) {
        if (objects === undefined) return;
        let object = objects[objectName];
        if (object !== undefined) {
            let property = object[propertyName];
            if (property !== undefined) {

                switch (mode) {
                    case 1:
                        settings[propertyName] = property;
                        break;
                    case 2:
                        let subProp1 = property["solid"];
                        if (subProp1 !== undefined) {
                            let subProp2 = subProp1["color"];
                            if (subProp2 !== undefined) {
                                settings[propertyName] = subProp2;
                            }
                        }
                        break;
                    case 5:
                        if (property < 0) settings[propertyName] = 0;
                        else settings[propertyName] = property;
                        break;
                    case 6:
                        if (property > 0) settings[propertyName] = 0;
                        else settings[propertyName] = property;
                        break;
                }
            }
        }
    }

    private enumerateRenderGroup() {
        let internalInstances: VisualObjectInstance[] = [];
        internalInstances.push( < VisualObjectInstance > {
            objectName: "renderGroup",
            selector: null,
            properties: {
                templateUrl: this.settings.templateUrl,
                targetUrl: this.settings.targetUrl,
                htmlType: this.settings.htmlType,
                widthType: this.settings.widthType
            }
        });
        if (this.settings.widthType === 2) {
            internalInstances.push( < VisualObjectInstance > {
                objectName: "renderGroup",
                selector: null,
                properties: {
                    htmlWidth: this.settings.htmlWidth
                }
            });
        } else {
            internalInstances.push( < VisualObjectInstance > {
                objectName: "renderGroup",
                selector: null,
                properties: {
                    fixedWidth: this.settings.fixedWidth
                }
            });
        }
        internalInstances.push( < VisualObjectInstance > {
            objectName: "renderGroup",
            selector: null,
            properties: {
                categoryShow: this.settings.categoryShow,
                padding: this.settings.padding,
                margin: this.settings.margin,
                borderShow: this.settings.borderShow
            }
        });
        if (this.settings.borderShow) {        
            internalInstances.push( < VisualObjectInstance > {
                objectName: "renderGroup",
                selector: null,
                properties: {
                    borderColor: this.settings.borderColor,
                    borderSize: this.settings.borderSize
                }
            });
        }
        return internalInstances;
    }

    private enumerateHtmlSetting() {
        let internalInstances: VisualObjectInstance[] = [];
        internalInstances.push( < VisualObjectInstance > {
            objectName: "htmlSetting",
            selector: null,
            properties: {
                sHtml: this.settings.sHtml
            }
        });
        if (!this.settings.sHtml) {
            internalInstances.push( < VisualObjectInstance > {
                objectName: "renderGroup",
                selector: null,
                properties: {
                    textAlign: this.settings.textAlign,
                    textColor: this.settings.textColor,
                    textSize: this.settings.textSize
                }
            });
        }
        return internalInstances;
    }

    private enumerateCategorySettings() {
        let internalInstances: VisualObjectInstance[] = [];
        internalInstances.push( < VisualObjectInstance > {
            objectName: "categorySettings",
            selector: null,
            properties: {
                categoryShow: this.settings.categoryShow
            }
        });
        if (this.settings.categoryShow) {
            internalInstances.push( < VisualObjectInstance > {
                objectName: "categorySettings",
                selector: null,
                properties: {
                    categoryFontFamily: this.settings.categoryFontFamily,
                    categoryFontSize: this.settings.categoryFontSize,
                    categoryFontColor: this.settings.categoryFontColor,
                    categoryFontWeight: this.settings.categoryFontWeight
                }
            });
        }
        return internalInstances;
    }

    public enumerateObjectInstances(options: EnumerateVisualObjectInstancesOptions): VisualObjectInstance[] | VisualObjectInstanceEnumerationObject {

        let internalInstances: VisualObjectInstance[] = [];
        switch (options.objectName) {
            case "renderGroup":
                return this.enumerateRenderGroup();
            case "htmlSetting":
                return this.enumerateHtmlSetting();
            case "categorySettings":
                return this.enumerateCategorySettings();
        }
    }
}